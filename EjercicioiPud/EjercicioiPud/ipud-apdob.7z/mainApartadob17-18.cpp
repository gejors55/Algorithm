// Examen junio 2016: Implementacion de un sistema de reproduccion de musica
// APDO B: hay que reducir los costes de deleteSong y play

#include "lista.h"
#include "DiccionarioHash.h"
#include <iostream>
#include <string>
using namespace std;

typedef string Cancion;
typedef string Artista;
class SongInfo {
public:
		Artista artist;
		int duration;
		// APDO B: sustituimos los booleanos por iteradores que apuntan al elemento de las listas
		// de reproducción y reproducidas donde están las canciones de las que el correspondiente 
		// objeto SongInfo es información
		//bool inPlaylist;
		//bool played;
		Lista<Cancion>::Iterator itPlaylist;
		Lista<Cancion>::Iterator itPlayed;
		// OJO: los constructores de los iteradores son privados
		// Definimos el siguiente constructor al que le pasaremos los end() de las listas correspondientes
		// cuando creemos un objeto en addSong
		SongInfo(const Lista<Cancion>::Iterator& itplaylist, const Lista<Cancion>::Iterator& itplayedlist) :
			itPlaylist(itplaylist), itPlayed(itplayedlist) {}
	};
// clases excepcion para iPud
class ECancionExistente{};
class ECancionNoExistente{};
// clase iPud
class iPud {	
	Lista<Cancion> playlist;
    Lista<Cancion> played;
	int duration;
	DiccionarioHash<Cancion,SongInfo> songs;
public:
	iPud() : duration(0) {}
	void addSong(const Cancion& c, const Artista& a, int d);
	void addToPlaylist(const Cancion& c);
	Cancion current();
	void play();
	void deleteSong(const Cancion& c);
	int totalTime(); 	
	Lista<Cancion> recent(int n);
};

void iPud::addSong(const Cancion& c, const Artista& a, int d){
	if (songs.contiene(c)) throw ECancionExistente();
	// creación de la información de la canción
	// APDO. B: Los iteradores de momento no tienen que apuntar a nada porque lo único
	// que estamos haciendo es meter la canción en la colección de canciones existentes
	SongInfo i(playlist.end(), played.end());
	i.artist = a; 
	i.duration = d; 
	// inclusión en el diccionario
	songs.inserta(c,i);
}

int main(){
	return 0;
}